﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var1Misha.Models
{
    internal class Student
    {
        public string? FullName { get; set; }
        public Grades? Gradles { get; set; }
    }
}
