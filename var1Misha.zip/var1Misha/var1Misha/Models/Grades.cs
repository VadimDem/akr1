﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var1Misha.Models
{
    internal class Grades
    {
        public int Math {  get; set; }
        public int Bio { get; set; }
        public int Practic { get; set; }
    }
}
