using System.ComponentModel;
using System.Text.Json;
using var1Misha.Models;

namespace var1Misha
{
    public partial class Form1 : Form
    {
        BindingList<Student> students = new BindingList<Student>();
        public Form1()
        {
            InitializeComponent();
            try
            {
                var file = File.ReadAllText("./data.json");
                students = JsonSerializer.Deserialize<BindingList<Student>>(file)!;
            }
            catch { }
            comboBox1.DataSource = new BindingSource(students, null);
            comboBox1.DisplayMember = "FullName";
          
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                var student = new Student();
                student.FullName = textBox1.Text;
                student.Gradles = new Grades();
                students.Add(student);
            }
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                var student = (Student)comboBox1.SelectedItem;
                dataGridView1.DataSource = new BindingSource(student.Gradles, null);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                students.Remove((Student)comboBox1.SelectedItem);
            }
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            var cell = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex];
            var color = default(Color);
            switch (cell.Value)
            {
                case 2:
                    color = Color.Red;
                    break;
                case 3:
                    color = Color.Orange;
                    break;
                case 4:
                    color = Color.Yellow;
                    break;
                case 5:
                    color = Color.Green;
                    break;
                default:
                    cell.Value = 2;
                    break;
            }
            cell.Style.BackColor = color;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // MessageBox.Show("�� ������ ��������� ������ ���������?", ""
            //      ,MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            Form2 form2 = new Form2();
            form2.ShowDialog();
            if (form2.DialogResult == DialogResult.Yes)
            {
                var contents = JsonSerializer.Serialize(students);
                File.WriteAllText("./data.json", contents);
            }
        }
    }
}
